let cartItems = [];
function addToCart(item, price) {
    cartItems.push({ item, price });
    localStorage.setItem("cart", JSON.stringify(cartItems));
    alert(`${item} added to cart!`);
}
function filterMenu(category) {
    let items = document.querySelectorAll(".item");
    items.forEach(item => {
        if (category === 'all' || item.classList.contains(category)) {
            item.classList.remove("hidden");
        } else {
            item.classList.add("hidden");
        }
    });
}